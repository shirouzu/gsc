# Google Search 100

Get 100 results from a Google search by H.Shirouzu (https://shirouzu.jp)

