"use strict";

let $ = function(id) { return document.getElementById(id); }
let gsc_is_firefox = typeof InstallTrigger !== 'undefined';
let gsc_opt = {};

gsc_opt.gsc_enabled = true;
gsc_opt.gsc_num = 100;

function gsc_save(cb) {
  chrome.storage.local.set({"gsc_opt": gsc_opt}, cb);
}

function gsc_load(cb) {
  try {
    chrome.storage.local.get("gsc_opt", async function(res) {
      let is_first = (res.gsc_opt === undefined);
      if (!is_first) {
        for (let key in gsc_opt) {
          if (key.substr(0, 3) != "gsc_")
            continue;
          if (res.gsc_opt[key] === undefined)
            res.gsc_opt[key] = gsc_opt[key]
        }
        gsc_opt = res.gsc_opt;
      }
      gsc_save();

      if (cb)
        cb();
    });
  }
  catch(e) {
    console.debug("gsc_load exception", e);
  }
}

async function reflect_state() {
  let dis_rules = [];
  let cur_rules = [];

  if (gsc_opt.gsc_enabled && gsc_opt.gsc_num == 25)
    cur_rules.push("gsc_rules_25");
  else
    dis_rules.push("gsc_rules_25");

  if (gsc_opt.gsc_enabled && gsc_opt.gsc_num == 50)
    cur_rules.push("gsc_rules_50");
  else
    dis_rules.push("gsc_rules_50");

  if (gsc_opt.gsc_enabled && gsc_opt.gsc_num == 100)
    cur_rules.push("gsc_rules_100");
  else
    dis_rules.push("gsc_rules_100");

  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: cur_rules,
    disableRulesetIds: dis_rules
  }, () => { console.debug("reflect_state1", cur_rules, chrome.runtime.lastError); } );
  chrome.action.setIcon({ path: gsc_opt.gsc_enabled ? "gsc16.png" : "gsc16-off.png" });
}

function gsc_tab_send_message(tab_id, msg, caller_id) {
  // console.debug("gsc_tab_send_message", tab_id, caller_id);
  chrome.tabs.get(tab_id, (tab) => {
    if (chrome.runtime.lastError)
      return;

    try {
      chrome.tabs.sendMessage(tab_id, msg, function() {
        if (chrome.runtime.lastError)
          console.debug("gsc_tab_send_message: res error", tab_id, chrome.runtime.lastError, caller_id);
      });
    }
    catch (e) {
      console.debug("gsc_tab_send_message: error", tab_id, e, caller_id);
      return;
    }
  });
  // console.debug("gsc_tab_send_message done", tab_id);
}

chrome.runtime.onMessage.addListener(function(msg, sender, res) {
  //console.log("gsc_onMessage(background)", msg, msg.gsc_opt ? msg.gsc_opt.gsc_enabled : null);

  try {
    if (sender.tab) {
      chrome.tabs.get(sender.tab.id, function(tab) {
        if (chrome.runtime.lastError /*|| !tab.active*/)
          return;

        if (msg.cmd == "load_via_optpage") {
          gsc_tab_send_message(sender.tab.id, { cmd: "load_done", gsc_opt: gsc_opt }, 2);
        }
        else if (msg.cmd == "save") {
          gsc_opt = msg.gsc_opt;
          gsc_save();
          reflect_state();
        }
        else {
          console.debug("gsc_onMessage(background): unknown cmd:", msg.cmd);
        }
        return true;
      });
    }
  }
  finally {
    res({status: "ok"});
  }

  return true;
});


chrome.action.onClicked.addListener(async () => {
  gsc_opt.gsc_enabled = !gsc_opt.gsc_enabled;
  reflect_state();
  gsc_save();
});

chrome.runtime.onInstalled.addListener(async () => {
  gsc_load(reflect_state);
});

chrome.runtime.onStartup.addListener(async () => {
  gsc_load(reflect_state);
});

gsc_load(reflect_state);

