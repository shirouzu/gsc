"use strict";

async function reflect_state(is_enabled) {
  if (is_enabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({
      enableRulesetIds: ['gsc_rules'],
      disableRulesetIds: []
    });
    chrome.action.setIcon({ path: "gsc16.png" });
  } else {
    await chrome.declarativeNetRequest.updateEnabledRulesets({
      enableRulesetIds: [],
      disableRulesetIds: ['gsc_rules']
    });
    chrome.action.setIcon({ path: "gsc16-off.png" });
  }
}

chrome.action.onClicked.addListener(async () => {
  const { gsc_enabled } = await chrome.storage.local.get(['gsc_enabled']);
  const is_enabled = !gsc_enabled;

  await reflect_state(is_enabled);
  await chrome.storage.local.set({ gsc_enabled: is_enabled });
});

chrome.runtime.onInstalled.addListener(async () => {
  const { gsc_enabled } = await chrome.storage.local.get(['gsc_enabled']);
  const is_enabled = gsc_enabled !== undefined ? gsc_enabled : true;

  await chrome.storage.local.set({ gsc_enabled: is_enabled });
  await reflect_state(is_enabled);
});

chrome.runtime.onStartup.addListener(async () => {
  const { gsc_enabled } = await chrome.storage.local.get(['gsc_enabled']);
  await reflect_state(gsc_enabled);
});

