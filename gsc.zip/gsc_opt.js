"use strict";

let $ = function(id) { return document.getElementById(id); }
let gsc_is_firefox = typeof InstallTrigger !== 'undefined';
let gsc_opt = {};

function gsc_load() {
  chrome.runtime.sendMessage({
      cmd: "load_via_optpage",
    }, function() {
      if (chrome.runtime.lastError)
        console.debug("gsc_load: res error", chrome.runtime.lastError);
  });
}

function gsc_save() {
  chrome.runtime.sendMessage({
      cmd: "save",
      gsc_opt: gsc_opt
    }, function() {
      if (chrome.runtime.lastError)
        console.debug("gsc_save: res error", chrome.runtime.lastError);
  });
}

function check_item(key) {
  gsc_opt[key] = $(key).checked ? 1 : 0;
  gsc_save();
}

function init_check_item(key, func) {
  let ele = $(key);
  if (!ele) {
    console.debug("%s not found", key);
    return;
  }
  ele.onclick = func ? func : function() { return check_item(key); };
  ele.checked = gsc_opt[key] ? true : false;
}

function select_item(key) {
  gsc_opt[key] = $(key).value;
  gsc_save();
  console.debug("gsc_opt[key]", gsc_opt[key]);
}

function init_select_item(key, func) {
  let ele = $(key);
  if (!ele) {
    console.debug("%s not found", key);
    return;
  }
  ele.value = gsc_opt[key];

  console.debug("set val", gsc_opt[key]);


  ele.onchange = function() {
    console.debug("onselect");
    select_item(key);
  }
}

function init_contents() {
  let opt_list = [
    "opt_home",
    "opt_select",
    "opt_enabled",
    "opt_histtitle",
    "opt_history",
    "opt_gpl"
  ];

  for (let key of opt_list) {
    try {
      let n = $(key);
      let v = chrome.i18n.getMessage(key);

      if (!n)
        continue;
      if (n.tagName == "TEXTAREA" || n.tagName == "INPUT")
        n.value = v
      else
        n.innerText = v;
    }
    catch(e) {}
  }
  $("opt_desc").innerText = chrome.runtime.getManifest().description;
  $("opt_ver").innerText = "ver " + chrome.runtime.getManifest().version;
}

function gsc_init() {
  init_contents();

  let chk_list = [
    "gsc_enabled"
  ];
  for (let key of chk_list)
    init_check_item(key);

  let sel_list = [
    "gsc_num"
  ];
  for (let key of sel_list)
    init_select_item(key);
}

window.onload = function() {
  gsc_load();
}

chrome.runtime.onMessage.addListener(function(req, sender, res) {
  console.debug("gsc_onMessage(option)", req, sender, res);

  if (req.cmd == "load_done") {
    gsc_opt = req.gsc_opt;
    gsc_init();
  }

  res({status: "ok"});

  return true;
});

